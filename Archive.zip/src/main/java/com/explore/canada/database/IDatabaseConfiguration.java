package com.explore.canada.database;

public interface IDatabaseConfiguration
{
	public String getDatabaseUserName();
	public String getDatabasePassword();
	public String getDatabaseUrl();
}
